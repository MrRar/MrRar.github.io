/**
 * Copy Paste Mod v1
 * @author Mr. Rar http://mrrar.ga/
 * block IDs 440-442
 * Feel free to edit this mod to your liking.
 */
using System;
using System.Collections.Generic;

namespace ManicDigger.Mods
{
	public class CopyPaste : IMod
	{
		public void PreStart(ModManager m)
		{
			m.RequireMod("CoreBlocks");
		}
		public void Start(ModManager manager)
		{
			m = manager;
			m.RegisterOnBlockBuild(OnBuild);
			m.RegisterOnBlockDelete(OnDelete);
			
			m.SetBlockType(440, "Copy", new BlockType()
			               {
			               	AllTextures = "Copy",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
							PickDistanceWhenUsed = 20f,
			               });
			m.SetBlockType(441, "Paste", new BlockType()
			               {
			               	AllTextures = "Paste",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
							PickDistanceWhenUsed = 20f,
			               });
			m.SetBlockType(442, "Delete", new BlockType()
			               {
			               	AllTextures = "Delete",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
							PickDistanceWhenUsed = 20f,
			               });
			m.AddToCreativeInventory("Copy");
			m.AddToCreativeInventory("Paste");
			m.AddToCreativeInventory("Delete");
		}
		ModManager m;
		public int[,,] Clipboard;
		public int[] CopyBlockXYZ = new int[3]; // stores coords of first placed copy block
		public int[] DeleteBlockXYZ = new int[3]; // stores coords of first placed delete block
		public bool OneCopyBlockSet = false; // when player sets the first copy block this will be changed to true.
		public bool OneDeleteBlockSet = false;
		void OnBuild(int playerID, int x, int y, int z){
			switch(m.GetBlock(x, y, z))
			{
				case 900:
					if(OneCopyBlockSet)
					{
						int lengthX = Math.Abs(x-CopyBlockXYZ[0]);
						int lengthY = Math.Abs(y-CopyBlockXYZ[1]);
						int lengthZ = Math.Abs(z-CopyBlockXYZ[2]);
						Clipboard = new int[lengthX,lengthY,lengthZ];
						int lowX = Math.Min(x,CopyBlockXYZ[0]);
						int lowY = Math.Min(y,CopyBlockXYZ[1]); // get lowest copy block
						int lowZ = Math.Min(z,CopyBlockXYZ[2]);
						for (int xx = 0; xx < lengthX; xx++)
						{
							for (int yy = 0; yy < lengthY; yy++)
							{
								for (int zz = 0; zz < lengthZ; zz++)
								{
									Clipboard[xx,yy,zz] = m.GetBlock(lowX+xx,lowY+yy,lowZ+zz);
								}
							}
						}
						m.SetBlock(CopyBlockXYZ[0],CopyBlockXYZ[1],CopyBlockXYZ[2],0);
						m.SetBlock(x,y,z,0);
						OneCopyBlockSet = false;
					}
					else
					{
						CopyBlockXYZ[0] = x;
						CopyBlockXYZ[1] = y;
						CopyBlockXYZ[2] = z;
						OneCopyBlockSet = true;
					}
				break;
				case 901:
					m.SetBlock(x,y,z,0);
					for (int xx = 1; xx < Clipboard.GetLength(0); xx++)
					{
						for (int yy = 1; yy < Clipboard.GetLength(1); yy++)
						{
							for (int zz = 1; zz < Clipboard.GetLength(2); zz++)
							{
								if(!(Clipboard[xx,yy,zz] == 0)) m.SetBlock(x+xx,y+yy,z+zz,Clipboard[xx,yy,zz]);
								// blank space will not be placed
							}
						}
					}
				break;
				case 902:
					if(OneDeleteBlockSet)
					{
						int lengthX = Math.Abs(x-DeleteBlockXYZ[0]);
						int lengthY = Math.Abs(y-DeleteBlockXYZ[1]);
						int lengthZ = Math.Abs(z-DeleteBlockXYZ[2]);
						int lowX = Math.Min(x,DeleteBlockXYZ[0]);
						int lowY = Math.Min(y,DeleteBlockXYZ[1]); // get lowest delete block
						int lowZ = Math.Min(z,DeleteBlockXYZ[2]);
						for (int xx = 1; xx < lengthX; xx++)
						{
							for (int yy = 1; yy < lengthY; yy++)
							{
								for (int zz = 1; zz < lengthZ; zz++)
								{
									m.SetBlock(lowX+xx,lowY+yy,lowZ+zz,0);
								}
							}
						}
						m.SetBlock(DeleteBlockXYZ[0],DeleteBlockXYZ[1],DeleteBlockXYZ[2],0);
						m.SetBlock(x,y,z,0);
						OneDeleteBlockSet = false;
					}
					else
					{
						DeleteBlockXYZ[0] = x;
						DeleteBlockXYZ[1] = y;
						DeleteBlockXYZ[2] = z;
						OneDeleteBlockSet = true;
					}
				break;
			}
		}
		void OnDelete(int playerID, int x, int y, int z, int blockID)
		{
			if(blockID == 900)
			{
				OneCopyBlockSet = false;
			}
			if(blockID == 902)
			{
				OneDeleteBlockSet = false;
			}
		}
	}
}
