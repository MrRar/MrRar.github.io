/******************************************
Alphabet Mod v1.0
Author:Mr. Rar
Block IDs used:402-431

Feel free to edit this mod to your liking.
*******************************************/

using System;

namespace ManicDigger.Mods
{

	public class Alphabet : IMod
	{
		ModManager m;
		SoundSet solidSounds;

		public void PreStart(ModManager m)
		{
			m.RequireMod("Core");
		}
		public void Start(ModManager manager)
		{
			m = manager;
			solidSounds = new SoundSet()
			{
				Walk = new string[] { "walk1", "walk2", "walk3", "walk4" },
				Break = new string[] { "destruct" },
				Build = new string[] { "build" },
				Clone = new string[] { "clone" },
			};
			
			 m.SetBlockType(402, "Space", new BlockType()
			               {
                            TextureIdForInventory = "Space",
                            AllTextures = "Space",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
			m.SetBlockType(403, "A", new BlockType()
			               {
                            TextureIdForInventory = "A", 
			               	TopBottomTextures = "Space",
                            SideTextures = "A",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(404, "B", new BlockType()
			               {
                            TextureIdForInventory = "B",
			               	TopBottomTextures = "Space",
                            SideTextures = "B",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(405, "C", new BlockType()
			               {
                            TextureIdForInventory = "C",
			               	TopBottomTextures = "Space",
                            SideTextures = "C",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(406, "D", new BlockType()
			               {
                            TextureIdForInventory = "D",
			               	TopBottomTextures = "Space",
                            SideTextures = "D",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(407, "E", new BlockType()
			               {
                            TextureIdForInventory = "E",
			               	TopBottomTextures = "Space",
                            SideTextures = "E",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(408, "F", new BlockType()
			               {
                            TextureIdForInventory = "F",                           
			               	TopBottomTextures = "Space",
                            SideTextures = "F",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(409, "G", new BlockType()
			               {
                            TextureIdForInventory = "G",
			               	TopBottomTextures = "Space",
                            SideTextures = "G",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(410, "H", new BlockType()
			               {
                            TextureIdForInventory = "H",
			               	TopBottomTextures = "Space",
                            SideTextures = "H",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(411, "I", new BlockType()
			               {
                            TextureIdForInventory = "I",
			               	TopBottomTextures = "Space",
                            SideTextures = "I",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(412, "J", new BlockType()
			               {
                            TextureIdForInventory = "J",
			               	TopBottomTextures = "Space",
                            SideTextures = "J",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(413, "K", new BlockType()
			               {
                            TextureIdForInventory = "K",
			               	TopBottomTextures = "Space",
                            SideTextures = "K",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(414, "L", new BlockType()
			               {
                            TextureIdForInventory = "L",
			               	TopBottomTextures = "Space",
                            SideTextures = "L",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(415, "M", new BlockType()
			               {
                            TextureIdForInventory = "M",
			               	TopBottomTextures = "Space",
                            SideTextures = "M",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(416, "N", new BlockType()
			               {
                            TextureIdForInventory = "N",
			               	TopBottomTextures = "Space",
                            SideTextures = "N",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(417, "O", new BlockType()
			               {
                            TextureIdForInventory = "O",
			               	TopBottomTextures = "Space",
                            SideTextures = "O",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(418, "P", new BlockType()
			               {
                            TextureIdForInventory = "P",
			               	TopBottomTextures = "Space",
                            SideTextures = "P",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(419, "Q", new BlockType()
			               {
                            TextureIdForInventory = "Q",
			               	TopBottomTextures = "Space",
                            SideTextures = "Q",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(420, "R", new BlockType()
			               {
                            TextureIdForInventory = "R",
			               	TopBottomTextures = "Space",
                            SideTextures = "R",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(421, "S", new BlockType()
			               {
                            TextureIdForInventory = "S",
			               	TopBottomTextures = "Space",
                            SideTextures = "S",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(422, "T", new BlockType()
			               {
                            TextureIdForInventory = "T",
			               	TopBottomTextures = "Space",
                            SideTextures = "T",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(423, "U", new BlockType()
			               {
                            TextureIdForInventory = "U",
			               	TopBottomTextures = "Space",
                            SideTextures = "U",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(424, "V", new BlockType()
			               {
                            TextureIdForInventory = "V",
			               	TopBottomTextures = "Space",
                            SideTextures = "V",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(425, "W", new BlockType()
			               {
                            TextureIdForInventory = "W",
			               	TopBottomTextures = "Space",
                            SideTextures = "W",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(426, "X", new BlockType()
			               {
                            TextureIdForInventory = "X",
			               	TopBottomTextures = "Space",
                            SideTextures = "X",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(427, "Y", new BlockType()
			               {
                            TextureIdForInventory = "Y",
			               	TopBottomTextures = "Space",
                            SideTextures = "Y",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(428, "Z", new BlockType()
			               {
                            TextureIdForInventory = "Z",
			               	TopBottomTextures = "Space",
                            SideTextures = "Z",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
             m.SetBlockType(430, "Dot", new BlockType()
			               {
                            TextureIdForInventory = "Dot",
			               	TopBottomTextures = "Dot",
                            SideTextures = "Dot",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
              m.SetBlockType(431, "Exclaim", new BlockType()
			               {
                            TextureIdForInventory = "Exclaim",
			               	TopBottomTextures = "Space",
                            SideTextures = "Exclaim",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.AddToCreativeInventory("Space");
			m.AddToCreativeInventory("A");
            m.AddToCreativeInventory("B");
            m.AddToCreativeInventory("C");
            m.AddToCreativeInventory("D");
            m.AddToCreativeInventory("E");
            m.AddToCreativeInventory("F");
            m.AddToCreativeInventory("G");
            m.AddToCreativeInventory("H");
            m.AddToCreativeInventory("I");
            m.AddToCreativeInventory("J");
            m.AddToCreativeInventory("K");
            m.AddToCreativeInventory("L");
            m.AddToCreativeInventory("M");
            m.AddToCreativeInventory("N");
            m.AddToCreativeInventory("O");
            m.AddToCreativeInventory("P");
            m.AddToCreativeInventory("Q");
            m.AddToCreativeInventory("R");
            m.AddToCreativeInventory("S");
            m.AddToCreativeInventory("T");
            m.AddToCreativeInventory("U");
            m.AddToCreativeInventory("V");
            m.AddToCreativeInventory("W");
            m.AddToCreativeInventory("X");
            m.AddToCreativeInventory("Y");
            m.AddToCreativeInventory("Z");
            m.AddToCreativeInventory("Dot");
            m.AddToCreativeInventory("Exclaim");
            m.AddCraftingRecipe("Space", 1, "OakWood", 2);
            m.AddCraftingRecipe("Space", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Space", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("A", 1, "OakWood", 2);
            m.AddCraftingRecipe("A", 1, "BirchWood", 2);
            m.AddCraftingRecipe("A", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("B", 1, "OakWood", 2);
            m.AddCraftingRecipe("B", 1, "BirchWood", 2);
            m.AddCraftingRecipe("B", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("C", 1, "OakWood", 2);
            m.AddCraftingRecipe("C", 1, "BirchWood", 2);
            m.AddCraftingRecipe("C", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("D", 1, "OakWood", 2);
            m.AddCraftingRecipe("D", 1, "BirchWood", 2);
            m.AddCraftingRecipe("D", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("E", 1, "OakWood", 2);
            m.AddCraftingRecipe("E", 1, "BirchWood", 2);
            m.AddCraftingRecipe("E", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("F", 1, "OakWood", 2);
            m.AddCraftingRecipe("F", 1, "BirchWood", 2);
            m.AddCraftingRecipe("F", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("G", 1, "OakWood", 2);
            m.AddCraftingRecipe("G", 1, "BirchWood", 2);
            m.AddCraftingRecipe("G", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("H", 1, "OakWood", 2);
            m.AddCraftingRecipe("H", 1, "BirchWood", 2);
            m.AddCraftingRecipe("H", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("I", 1, "OakWood", 2);
            m.AddCraftingRecipe("I", 1, "BirchWood", 2);
            m.AddCraftingRecipe("I", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("J", 1, "OakWood", 2);
            m.AddCraftingRecipe("J", 1, "BirchWood", 2);
            m.AddCraftingRecipe("J", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("K", 1, "OakWood", 2);
            m.AddCraftingRecipe("K", 1, "BirchWood", 2);
            m.AddCraftingRecipe("K", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("L", 1, "OakWood", 2);
            m.AddCraftingRecipe("L", 1, "BirchWood", 2);
            m.AddCraftingRecipe("L", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("M", 1, "OakWood", 2);
            m.AddCraftingRecipe("M", 1, "BirchWood", 2);
            m.AddCraftingRecipe("M", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("N", 1, "OakWood", 2);
            m.AddCraftingRecipe("N", 1, "BirchWood", 2);
            m.AddCraftingRecipe("N", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("O", 1, "OakWood", 2);
            m.AddCraftingRecipe("O", 1, "BirchWood", 2);
            m.AddCraftingRecipe("O", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("P", 1, "OakWood", 2);
            m.AddCraftingRecipe("P", 1, "BirchWood", 2);
            m.AddCraftingRecipe("P", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("Q", 1, "OakWood", 2);
            m.AddCraftingRecipe("Q", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Q", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("R", 1, "OakWood", 2);
            m.AddCraftingRecipe("R", 1, "BirchWood", 2);
            m.AddCraftingRecipe("R", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("S", 1, "OakWood", 2);
            m.AddCraftingRecipe("S", 1, "BirchWood", 2);
            m.AddCraftingRecipe("S", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("T", 1, "OakWood", 2);
            m.AddCraftingRecipe("T", 1, "BirchWood", 2);
            m.AddCraftingRecipe("T", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("U", 1, "OakWood", 2);
            m.AddCraftingRecipe("U", 1, "BirchWood", 2);
            m.AddCraftingRecipe("U", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("V", 1, "OakWood", 2);
            m.AddCraftingRecipe("V", 1, "BirchWood", 2);
            m.AddCraftingRecipe("V", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("W", 1, "OakWood", 2);
            m.AddCraftingRecipe("W", 1, "BirchWood", 2);
            m.AddCraftingRecipe("W", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("X", 1, "OakWood", 2);
            m.AddCraftingRecipe("X", 1, "BirchWood", 2);
            m.AddCraftingRecipe("X", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("Y", 1, "OakWood", 2);
            m.AddCraftingRecipe("Y", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Y", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("Z", 1, "OakWood", 2);
            m.AddCraftingRecipe("Z", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Z", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("Dot", 1, "OakWood", 2);
            m.AddCraftingRecipe("Dot", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Dot", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("Exclaim", 1, "OakWood", 2);
            m.AddCraftingRecipe("Exclaim", 1, "BirchWood", 2);
            m.AddCraftingRecipe("Exclaim", 1, "SpruceWood", 2);

		}
	}
}
