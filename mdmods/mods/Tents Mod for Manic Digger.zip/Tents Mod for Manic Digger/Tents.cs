//      A                        A
//     /|\                      /|\
//    / | \    TENTS MOD v1    / | \
//   /  |  \                  /  |  \
//Wv/___|___\vWvWWVvWvWwvVwVw/___|___\wV
//
// Author: Mr. Rar
// block id used: 400
// Feel free to edit this mod to your liking.
//
using System;

namespace ManicDigger.Mods
{
	public class Tents : IMod
	{
        SoundSet noSound;
		public void PreStart(ModManager m)
		{
			m.RequireMod("CoreBlocks");
		}
		public void Start(ModManager manager)
		{
            			noSound = new SoundSet();
			m = manager;
            m.SetBlockType(400, "Tent", new BlockType()
            {
               TextureIdTop = "Boxtop",
               TextureIdBottom = "Boxtop",
               SideTextures = "Tent",
               TextureIdForInventory = "Tent",
			   DrawType = DrawType.Solid,
			   WalkableType = WalkableType.Solid,
			   Sounds = noSound,
               IsUsable = true,
            });
			m.RegisterOnBlockUse(OnUse);
            m.AddCraftingRecipe("Tent", 1, "OakLeaves", 35);
            m.AddCraftingRecipe("Tent", 1, "BirchLeaves", 35);
            m.AddCraftingRecipe("Tent", 1, "SpruceLeaves", 35);
            m.AddToCreativeInventory("Tent");
			BlueCarpet = m.GetBlockId("BlueCarpet");
			WhiteCloth = m.GetBlockId("WhiteCloth");
		}
		ModManager m;
		int BlueCarpet;
		int WhiteCloth;

		void OnUse(int player, int x, int y, int z)
		{
            if(m.GetBlock(x, y, z) == 400 && m.IsValidPos(x-2, y-1, z) && m.IsValidPos(x+2, y-1, z+2))
            {
                
                int x1 = (int)Math.Round(m.GetPlayerPositionX(player), 0);
				int y1 = (int)Math.Round(m.GetPlayerPositionY(player), 0);
                int yDistance = x1 - x;
                int xDistance = y1 - y;
                if(yDistance < 0)yDistance = -yDistance;
                if(xDistance < 0)xDistance = -xDistance;
                
            if(yDistance <= xDistance)
            {
				m.SetBlock(x, y, z, BlueCarpet);
                m.SetBlock(x-1, y, z, BlueCarpet);
                m.SetBlock(x+1, y, z, BlueCarpet);
                m.SetBlock(x, y+1, z, BlueCarpet);
                m.SetBlock(x-1, y+1, z, BlueCarpet);
                m.SetBlock(x+1, y+1, z, BlueCarpet);
                m.SetBlock(x, y+2, z, BlueCarpet);
                m.SetBlock(x-1, y+2, z, BlueCarpet);
                m.SetBlock(x+1, y+2, z, BlueCarpet);
                m.SetBlock(x, y-1, z, BlueCarpet);
                m.SetBlock(x-1, y-1, z, BlueCarpet);
                m.SetBlock(x+1, y-1, z, BlueCarpet);
                m.SetBlock(x, y-2, z, BlueCarpet);
                m.SetBlock(x-1, y-2, z, BlueCarpet);
                m.SetBlock(x+1, y-2, z, BlueCarpet);
               
                m.SetBlock(x+2, y-2, z, WhiteCloth);
                m.SetBlock(x+2, y-1, z, WhiteCloth);
                m.SetBlock(x+2, y, z, WhiteCloth);
                m.SetBlock(x+2, y+1, z, WhiteCloth);
                m.SetBlock(x+2, y+2, z, WhiteCloth);
            
                m.SetBlock(x+2, y-2, z+1, WhiteCloth);
                m.SetBlock(x+2, y-1, z+1, WhiteCloth);
                m.SetBlock(x+2, y, z+1, WhiteCloth);
                m.SetBlock(x+2, y+1, z+1, WhiteCloth);
                m.SetBlock(x+2, y+2, z+1, WhiteCloth);
            
                m.SetBlock(x+1, y-2, z+2, WhiteCloth);
                m.SetBlock(x+1, y-1, z+2, WhiteCloth);
                m.SetBlock(x+1, y, z+2, WhiteCloth);
                m.SetBlock(x+1, y+1, z+2, WhiteCloth);
                m.SetBlock(x+1, y+2, z+2, WhiteCloth);
            
                m.SetBlock(x, y-2, z+3, WhiteCloth);
                m.SetBlock(x, y-1, z+3, WhiteCloth);
                m.SetBlock(x, y, z+3, WhiteCloth);
                m.SetBlock(x, y+1, z+3, WhiteCloth);
                m.SetBlock(x, y+2, z+3, WhiteCloth);
            
                m.SetBlock(x-2, y-2, z, WhiteCloth);
                m.SetBlock(x-2, y-1, z, WhiteCloth);
                m.SetBlock(x-2, y, z, WhiteCloth);
                m.SetBlock(x-2, y+1, z, WhiteCloth);
                m.SetBlock(x-2, y+2, z, WhiteCloth);
            
                m.SetBlock(x-2, y-2, z+1, WhiteCloth);
                m.SetBlock(x-2, y-1, z+1, WhiteCloth);
                m.SetBlock(x-2, y, z+1, WhiteCloth);
                m.SetBlock(x-2, y+1, z+1, WhiteCloth);
                m.SetBlock(x-2, y+2, z+1, WhiteCloth);
            
                m.SetBlock(x-1, y-2, z+2, WhiteCloth);
                m.SetBlock(x-1, y-1, z+2, WhiteCloth);
                m.SetBlock(x-1, y, z+2, WhiteCloth);
                m.SetBlock(x-1, y+1, z+2, WhiteCloth);
                m.SetBlock(x-1, y+2, z+2, WhiteCloth);
            }
                else
                {
                m.SetBlock(x, y, z, BlueCarpet);
                m.SetBlock(x-1, y, z, BlueCarpet);
                m.SetBlock(x+1, y, z, BlueCarpet);
                m.SetBlock(x, y+1, z, BlueCarpet);
                m.SetBlock(x-1, y+1, z, BlueCarpet);
                m.SetBlock(x+1, y+1, z, BlueCarpet);
                m.SetBlock(x+2, y, z, BlueCarpet);
                m.SetBlock(x+2, y-1, z, BlueCarpet);
                m.SetBlock(x+2, y+1, z, BlueCarpet);
                m.SetBlock(x, y-1, z, BlueCarpet);
                m.SetBlock(x-1, y-1, z, BlueCarpet);
                m.SetBlock(x+1, y-1, z, BlueCarpet);
                m.SetBlock(x-2, y, z, BlueCarpet);
                m.SetBlock(x-2, y-1, z, BlueCarpet);
                m.SetBlock(x-2, y+1, z, BlueCarpet);  
                
                m.SetBlock(x-2, y+2, z, WhiteCloth); 
                m.SetBlock(x-1, y+2, z, WhiteCloth); 
                m.SetBlock(x, y+2, z, WhiteCloth); 
                m.SetBlock(x+1, y+2, z, WhiteCloth);
                m.SetBlock(x+2, y+2, z, WhiteCloth);
                    
                m.SetBlock(x-2, y+2, z+1, WhiteCloth); 
                m.SetBlock(x-1, y+2, z+1, WhiteCloth); 
                m.SetBlock(x, y+2, z+1, WhiteCloth); 
                m.SetBlock(x+1, y+2, z+1, WhiteCloth);
                m.SetBlock(x+2, y+2, z+1, WhiteCloth);
                    
                m.SetBlock(x-2, y+1, z+2, WhiteCloth); 
                m.SetBlock(x-1, y+1, z+2, WhiteCloth); 
                m.SetBlock(x, y+1, z+2, WhiteCloth); 
                m.SetBlock(x+1, y+1, z+2, WhiteCloth);
                m.SetBlock(x+2, y+1, z+2, WhiteCloth);
                    
                m.SetBlock(x-2, y, z+3, WhiteCloth); 
                m.SetBlock(x-1, y, z+3, WhiteCloth); 
                m.SetBlock(x, y, z+3, WhiteCloth); 
                m.SetBlock(x+1, y, z+3, WhiteCloth);
                m.SetBlock(x+2, y, z+3, WhiteCloth);
                    
                m.SetBlock(x-2, y-2, z, WhiteCloth); 
                m.SetBlock(x-1, y-2, z, WhiteCloth); 
                m.SetBlock(x, y-2, z, WhiteCloth); 
                m.SetBlock(x+1, y-2, z, WhiteCloth);
                m.SetBlock(x+2, y-2, z, WhiteCloth);
                    
                m.SetBlock(x-2, y-2, z+1, WhiteCloth); 
                m.SetBlock(x-1, y-2, z+1, WhiteCloth); 
                m.SetBlock(x, y-2, z+1, WhiteCloth); 
                m.SetBlock(x+1, y-2, z+1, WhiteCloth);
                m.SetBlock(x+2, y-2, z+1, WhiteCloth);
                    
                m.SetBlock(x-2, y-1, z+2, WhiteCloth); 
                m.SetBlock(x-1, y-1, z+2, WhiteCloth); 
                m.SetBlock(x, y-1, z+2, WhiteCloth); 
                m.SetBlock(x+1, y-1, z+2, WhiteCloth);
                m.SetBlock(x+2, y-1, z+2, WhiteCloth);
                }
            }
        }
	}
}
