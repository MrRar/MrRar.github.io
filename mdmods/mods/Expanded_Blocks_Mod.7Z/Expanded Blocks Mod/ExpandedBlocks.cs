    //////  //  //  /////     //    //  //  /////   //////  /////
   //      //  //  //  //  //  //  /// //  //  //  //      //  //
  //////   ////   /////   //////  //////  //  //  //////  //  //
 //      //  //  //      //  //  // ///  //  //  //      //  //
//////  //  //  //      //  //  //  //  /////   //////  /////

      /////   //       ////    /////  //  //   /////
     //  //  //      //  //  //      // //   //   
    /////   //      //  //  //      ////     ////
   //  //  //      //  //  //      // //        //
  /////   //////   ////    /////  //   //  /////

       //    //  ////   /////
      ///  /// //  //  //  //
     // // // //  //  //  //
    //    // //  //  //  //
   //    //  ////   /////
   
/*********************************************
Version: 1.0  Author: Mr. Rar
Defult Block IDs used: 449-506
Easily change the block ID range by editing
line 449.
Feel free to edit this mod to your liking.
*********************************************/

using System;
namespace ManicDigger.Mods
{
	public class ExpandedBlocks : IMod
	{
		SoundSet solidSounds;
		SoundSet snowSounds;
		SoundSet noSound;
        
		public void PreStart(ModManager m)
		{
			m.RequireMod("Core");
		}
		public void Start(ModManager manager)
		{
			m = manager;
            
			m.RegisterTimer(UpdateSeasons, 1);

			noSound = new SoundSet();
			solidSounds = new SoundSet()
			{
				Walk = new string[] { "walk1", "walk2", "walk3", "walk4" },
				Break = new string[] { "destruct" },
				Build = new string[] { "build" },
				Clone = new string[] { "clone" },
			};
			snowSounds = new SoundSet()
			{
				Walk = new string[] { "walksnow1", "walksnow2", "walksnow3", "walksnow4" },
				Break = new string[] { "destruct" },
				Build = new string[] { "build" },
				Clone = new string[] { "clone" },
			};

            
            //The bellow number sets the range of all block IDs used. It is added to numbers 0 through 57.
            n = 449;
            
            int Hand = m.GetBlockId("EmptyHand");
			 m.SetBlockType(Hand, "EmptyHand", new BlockType()
			      {
			         TextureIdTop = "HandTop",
			         TextureIdBottom = "HandTop",
			         SideTextures = "HandSide",
			         TextureIdForInventory = "HandSide",
			         DrawType = DrawType.Torch,
			         WalkableType = WalkableType.Empty,
			         Sounds = noSound,
			     });
            m.SetBlockType(n, "Steel", new BlockType()
				{
					AllTextures = "Steel",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+1, "SteelHalf", new BlockType()
				{
					TopBottomTextures = "Steel",
					SideTextures = "Steel",
					TextureIdForInventory = "SteelHalfInventory",
					DrawType = DrawType.HalfHeight,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+2, "TerracottaRoof", new BlockType()
                {
                    AllTextures = "TerracottaRoof",
                    DrawType = DrawType.Solid,
                    WalkableType = WalkableType.Solid,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+3, "TerracottaRoofHalf", new BlockType()
				{
					TopBottomTextures = "TerracottaRoof",
					SideTextures = "TerracottaRoofHalf",
					TextureIdForInventory = "TerracottaRoofHalfInventory",
					DrawType = DrawType.HalfHeight,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+4, "LuxuryRoofHalf", new BlockType()
				{
					TopBottomTextures = "LuxuryRoof",
					SideTextures = "LuxuryRoofHalf",
					TextureIdForInventory = "LuxuryRoofHalfInventory",
					DrawType = DrawType.HalfHeight,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+5, "RoofHalf", new BlockType()
				{
					TopBottomTextures = "Roof",
					SideTextures = "RoofHalf",
					TextureIdForInventory = "RoofHalfInventory",
					DrawType = DrawType.HalfHeight,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+6, "CinderBlock", new BlockType()
                {
                    AllTextures = "CinderBlock",
                    DrawType = DrawType.Solid,
                    WalkableType = WalkableType.Solid,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+7, "RoughBrick", new BlockType()
                {
                    AllTextures = "RoughBrick",
                    DrawType = DrawType.Solid,
                    WalkableType = WalkableType.Solid,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+8, "ClearGlass", new BlockType()
				{
					TopBottomTextures = "ClearGlass",
					SideTextures = "ClearGlass",
					TextureIdForInventory = "ClearGlassInventory",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+9, "FancyGlass", new BlockType()
				{
				    AllTextures = "FancyGlass",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+10, "LandMine", new BlockType()
				{
				    AllTextures = "LandMine",
					TextureIdForInventory = "LandMineInventory",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
                    DamageToPlayer = 100,
				});
            m.SetBlockType(n+11, "SpiderWeb", new BlockType()
                {
                    AllTextures = "Web",
                    DrawType = DrawType.Plant,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+12, "Pizza", new BlockType()
                {
                   TextureIdTop = "Pizza",
					TextureIdBottom = "PizzaBottom",
					TextureIdFront = "PizzaBottom",
                    TextureIdBack = "PizzaBottom",
                    TextureIdLeft = "PizzaBottom",
                    TextureIdRight = "PizzaBottom", 
                    TextureIdForInventory = "Pizza",
					DrawType = DrawType.Flat,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+13, "PoisonIvy", new BlockType()
				{
					AllTextures = "PoisonIvy",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
					DamageToPlayer = 1,
				});
            m.SetBlockType(n+14, "Tulip", new BlockType()
				{
					AllTextures = "FlowerTulip",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+15, "DandelionSeed", new BlockType()
				{
					AllTextures = "FlowerDandelionSeed",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});	
            m.SetBlockType(n+16, "Geranium", new BlockType()
				{
					AllTextures = "FlowerGeranium",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});	
            m.SetBlockType(n+17, "Dandelion", new BlockType()
				{
					AllTextures = "FlowerDandelion",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+18, "FlowerPot", new BlockType()
                {
                   TextureIdTop = "FlowerPotTop",
					TextureIdBottom = "FlowerPotBottom",
					TextureIdFront = "FlowerPotSide",
                    TextureIdBack = "FlowerPotSide",
                    TextureIdLeft = "FlowerPotSide",
                    TextureIdRight = "FlowerPotSide", 
                    TextureIdForInventory = "FlowerPotSide",
					DrawType = DrawType.Cactus,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+19, "Pillar", new BlockType()
				{
					SideTextures = "Pillar",
                    TopBottomTextures = "PillarTop",
                    TextureIdForInventory = "Pillar",
					DrawType = DrawType.Cactus,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});	
            m.SetBlockType(n+20, "ToxicGoo", new BlockType()
				{
					AllTextures = "ToxicGoo",
					DrawType = DrawType.Fluid,
					WalkableType = WalkableType.Fluid,
					Sounds = solidSounds,
                    LightRadius = 7,
                    DamageToPlayer = 1,
				});
            m.SetBlockType(n+21, "WoodSiding", new BlockType()
                {
                    AllTextures = "WoodSiding",
                    DrawType = DrawType.Solid,
                    WalkableType = WalkableType.Solid,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+22, "PumpkinSeed", new BlockType()
                {
                    AllTextures = "PumpkinSeed",
					TextureIdForInventory = "PumpkinSeedInventory",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+23, "PumpkinPlant", new BlockType()
                {
                    AllTextures = "PumpkinPlant",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+24, "Pumpkin", new BlockType()
                {
                    TextureIdTop = "PumpkinTop",
                    TextureIdBottom = "PumpkinBottom",
					SideTextures = "PumpkinSide",
					TextureIdForInventory = "PumpkinSide",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+25, "Jack-o-lantern", new BlockType()
                {
                    TextureIdBottom = "PumpkinBottom",
                    TextureIdTop = "PumpkinTop",
					SideTextures = "Jack-o-lantern",
					TextureIdForInventory = "Jack-o-lantern",
                    LightRadius = 10,
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+26, "CheckeredFloor", new BlockType()
                {
                    TopBottomTextures = "FloorCheckered",
					SideTextures = "FloorCheckered",
					TextureIdForInventory = "FloorCheckeredInventory",
                    DrawType = DrawType.Flat,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+27, "SpruceFloor", new BlockType()
                {
                    AllTextures = "FloorSpruce",
                    TextureIdForInventory = "FloorSpruceInventory",
                    DrawType = DrawType.Flat,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+28, "BirchFloor", new BlockType()
                {
                    AllTextures = "FloorBirch",
                    TextureIdForInventory = "FloorBirchInventory",
                    DrawType = DrawType.Flat,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+29, "OakFloor", new BlockType()
                {
                    AllTextures = "FloorOak",
                    TextureIdForInventory = "FloorOakInventory",
                    DrawType = DrawType.Flat,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+30, "WhiteFlag", new BlockType()
				{
					AllTextures = "FlagWhite",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+31, "RedFlag", new BlockType()
				{
					AllTextures = "FlagRed",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+32, "BlueFlag", new BlockType()
				{
					AllTextures = "FlagBlue",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+33, "WireFence", new BlockType()
				{
					AllTextures = "WireFence",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+34, "JailBars", new BlockType()
				{
					AllTextures = "JailBars",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+35, "WoodFenceGateClosed", new BlockType()
				{
					AllTextures = "WoodFenceGate",
					DrawType = DrawType.ClosedDoor,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});	
            m.SetBlockType(n+36, "WoodFenceGateOpen", new BlockType()
				{
					AllTextures = "WoodFenceGate",
					DrawType = DrawType.OpenDoorLeft,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+37, "WoodFence", new BlockType()
				{
					AllTextures = "WoodFence",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+38, "IronTrapdoorClosed", new BlockType()
				{
                    TopBottomTextures = "TrapdoorIron",
                    SideTextures = "TrapdoorIronSide",
                    TextureIdForInventory = "TrapdoorIron",
					DrawType = DrawType.Flat,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+39, "IronTrapdoorOpen", new BlockType()
				{
                    AllTextures = "TrapdoorIron",
					DrawType = DrawType.Ladder,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+40, "WoodenTrapdoorClosed", new BlockType()
				{
				    TopBottomTextures = "TrapdoorWood",
                    SideTextures = "TrapdoorWoodSide",
                    TextureIdForInventory = "TrapdoorWood",
					DrawType = DrawType.Flat,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+41, "WoodenTrapdoorOpen", new BlockType()
				{
					AllTextures = "TrapdoorWood",
					DrawType = DrawType.Ladder,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+42, "RecordPlayer", new BlockType()
                {
                    TextureIdTop = "recordTop",
					TextureIdBottom = "recordBottom",
					TextureIdFront = "recordFront",
                    TextureIdBack = "recordFront",
                    TextureIdLeft = "recordSide",
                    TextureIdRight = "recordSide",
					TextureIdForInventory = "recordTop",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+43, "Keyboard", new BlockType()
                {
                    TextureIdTop = "KeyboardTop",
					TextureIdBottom = "KeyboardBottom",
					TextureIdFront = "KeyboardFront",
                    TextureIdBack = "KeyboardBack",
                    TextureIdLeft = "KeyboardLeft",
                    TextureIdRight = "KeyboardRight",
					TextureIdForInventory = "KeyboardTop",
					DrawType = DrawType.HalfHeight,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+44, "Drawers", new BlockType()
				{
					TextureIdTop = "DrawersTop",
					TextureIdBottom = "DrawersBottom",
					SideTextures = "DrawersSide",
					TextureIdForInventory = "DrawersSide",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				});
            m.SetBlockType(n+45, "ComputerON", new BlockType()
                {
                    TextureIdTop = "computerTop",
					TextureIdBottom = "computerBottom",
					TextureIdFront = "computerFrontOn",
                    TextureIdBack = "computerBack",
                    TextureIdLeft = "computerLeft",
                    TextureIdRight = "computerRight",
					TextureIdForInventory = "computerFrontOn",
                    LightRadius = 8,
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+46, "ComputerOFF", new BlockType()
                {
                    TextureIdTop = "computerTop",
					TextureIdBottom = "computerBottom",
					TextureIdFront = "computerFrontOff",
                    TextureIdBack = "computerBack",
                    TextureIdLeft = "computerLeft",
                    TextureIdRight = "computerRight",
					TextureIdForInventory = "computerFrontOff",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+47, "TV_ON", new BlockType()
                {
                    TextureIdTop = "TVtop",
					TextureIdBottom = "TVbottom",
					TextureIdFront = "TVfrontON",
                    TextureIdBack = "TVback",
                    TextureIdLeft = "TVleft",
                    TextureIdRight = "TVright",
					TextureIdForInventory = "TVfrontON",
                    LightRadius = 8,
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+48, "TV_OFF", new BlockType()
                {
                    TextureIdTop = "TVtop",
					TextureIdBottom = "TVbottom",
					TextureIdFront = "TVfrontOFF",
                    TextureIdBack = "TVback",
                    TextureIdLeft = "TVleft",
                    TextureIdRight = "TVright",
					TextureIdForInventory = "TVfrontOFF",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+49, "Candle", new BlockType()
                {
                    AllTextures = "Candle",
                    LightRadius = 8,
                    DrawType = DrawType.Plant,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                });
            m.SetBlockType(n+50, "LampON", new BlockType()
				{
					TextureIdTop = "LampTopON",
					TextureIdBottom = "LampBottomON",
					SideTextures = "LampSideON",
					TextureIdForInventory = "LampSideON",
                    LightRadius = 15,
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+51, "LampOFF", new BlockType()
				{
					TextureIdTop = "LampTopOFF",
					TextureIdBottom = "LampBottomOFF",
					SideTextures = "LampSideOFF",
					TextureIdForInventory = "LampSideOFF",
					DrawType = DrawType.Solid,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+52, "LightBulbON", new BlockType()
                {
                    AllTextures = "LightBulbON",
                    LightRadius = 15,
                    DrawType = DrawType.Plant,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                    IsUsable = true,
                });
            m.SetBlockType(n+53, "LightBulbOFF", new BlockType()
                {
                    AllTextures = "LightBulbOFF",
                    DrawType = DrawType.Plant,
                    WalkableType = WalkableType.Empty,
                    Sounds = solidSounds,
                    IsUsable = true,
                });
            m.SetBlockType(n+54, "FluoressentTubeON", new BlockType()
				{
					TextureIdTop = "FluoressentTubeON",
					TextureIdBottom = "FluoressentTubeON",
					SideTextures = "FluoressentTubeON",
					TextureIdForInventory = "FluoressentInventoryON",
					LightRadius = 15,
					DrawType = DrawType.Torch,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+55, "FluoressentTubeOFF", new BlockType()
				{
					TextureIdTop = "FluoressentTubeOFF",
					TextureIdBottom = "FluoressentTubeOFF",
					SideTextures = "FluoressentTubeOFF",
					TextureIdForInventory = "FluoressentInventoryOFF",
					DrawType = DrawType.Torch,
					WalkableType = WalkableType.Empty,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+56, "ChandelierON", new BlockType()
				{
					AllTextures = "ChandelierON",
                    LightRadius = 15,
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});
            m.SetBlockType(n+57, "ChandelierOFF", new BlockType()
				{
					AllTextures = "ChandelierOFF",
					DrawType = DrawType.Plant,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
                    IsUsable = true,
				});

            m.AddToCreativeInventory("PoisonIvy");
            m.AddToCreativeInventory("Steel");
            m.AddToCreativeInventory("LampON");
            m.AddToCreativeInventory("ClearGlass");
            m.AddToCreativeInventory("FluoressentTubeON");
            m.AddToCreativeInventory("WireFence");
            m.AddToCreativeInventory("LandMine");
            m.AddToCreativeInventory("Tulip");
            m.AddToCreativeInventory("DandelionSeed");
            m.AddToCreativeInventory("Geranium");
            m.AddToCreativeInventory("Dandelion");
            m.AddToCreativeInventory("ChandelierON");
            m.AddToCreativeInventory("Pillar");
            m.AddToCreativeInventory("ToxicGoo");
            m.AddToCreativeInventory("SteelHalf");
            m.AddToCreativeInventory("WoodSiding");
            m.AddToCreativeInventory("Jack-o-lantern");
            m.AddToCreativeInventory("CinderBlock");
            m.AddToCreativeInventory("CheckeredFloor");
            m.AddToCreativeInventory("TV_OFF");
            m.AddToCreativeInventory("WoodFence");
            m.AddToCreativeInventory("WhiteFlag");
            m.AddToCreativeInventory("RedFlag");
            m.AddToCreativeInventory("BlueFlag");
            m.AddToCreativeInventory("LightBulbON");
            m.AddToCreativeInventory("Candle");
            m.AddToCreativeInventory("TerracottaRoof");
            m.AddToCreativeInventory("TerracottaRoofHalf");
            m.AddToCreativeInventory("LuxuryRoofHalf");
            m.AddToCreativeInventory("RoofHalf");
            m.AddToCreativeInventory("JailBars");
            m.AddToCreativeInventory("FancyGlass");
            m.AddToCreativeInventory("SpiderWeb");
            m.AddToCreativeInventory("RecordPlayer");
            m.AddToCreativeInventory("ComputerOFF");
            m.AddToCreativeInventory("Keyboard");
            m.AddToCreativeInventory("Pizza");
            m.AddToCreativeInventory("FlowerPot");
            m.AddToCreativeInventory("WoodFenceGateClosed");
            m.AddToCreativeInventory("Drawers");
            m.AddToCreativeInventory("WoodenTrapdoorClosed");
            m.AddToCreativeInventory("IronTrapdoorClosed");
            m.AddToCreativeInventory("OakFloor");
            m.AddToCreativeInventory("SpruceFloor");
            m.AddToCreativeInventory("BirchFloor");
            m.AddToCreativeInventory("PumpkinSeed");
            m.AddToCreativeInventory("Pumpkin");
            m.AddToCreativeInventory("PumpkinPlant");
            m.AddToCreativeInventory("RoughBrick");
            
            m.AddCraftingRecipe("Steel", 1, "IronBlock", 2);
            m.AddCraftingRecipe("OakFloor", 2,"OakWood", 1);
            m.AddCraftingRecipe("BirchFloor", 2,"BirchWood", 1);
            m.AddCraftingRecipe("SpruceFloor", 2,"SpruceWood", 1);
            m.AddCraftingRecipe("ComputerOFF",1, "IronBlock", 8);
            m.AddCraftingRecipe("TV_OFF", 1,"IronBlock", 8);
            m.AddCraftingRecipe("JailBars", 2, "IronBlock", 1);
            m.AddCraftingRecipe("LandMine", 1, "IronBlock", 1);
            m.AddCraftingRecipe2("LampON", 1, "IronBlock", 1, "Torch", 1);
            m.AddCraftingRecipe2("LightBulbON", 1, "IronBlock", 1, "Torch", 1);
            m.AddCraftingRecipe2("FluoressentTubeON", 1, "IronBlock", 1, "Torch", 1);
            m.AddCraftingRecipe2("LampON", 2, "IronBlock", 1, "Torch", 1);
            m.AddCraftingRecipe("RoughBrick", 1,"Stone", 2);
            m.AddCraftingRecipe("SinderBlock", 1, "Stone", 2);
            m.AddCraftingRecipe("WoodFence", 1, "OakWood", 2);
            m.AddCraftingRecipe("WoodFence", 1, "SpruceWood", 2);
            m.AddCraftingRecipe("WoodFence", 1, "BirchWood", 2);
            m.AddCraftingRecipe2("WoodFenceGate", 1, "OakPlanks", 2, "IronBlock", 1);
            m.AddCraftingRecipe2("WoodFenceGate", 1, "SprucePlanks", 2, "IronBlock", 1);
            m.AddCraftingRecipe2("WoodFenceGate", 1, "BirchPlanks", 2, "IronBlock", 1);
            m.AddCraftingRecipe("ClearGlass", 1, "Sand", 4);
            m.AddCraftingRecipe("Jack-o-lantern", 1, "Pumpkin", 1);
            m.AddCraftingRecipe("Pizza", 1, "Pumkin", 1);
            
            TV0 = m.GetBlockId("TV_ON");
            TV1 = m.GetBlockId("TV_OFF");
            Computer0 = m.GetBlockId("ComputerOFF");
            Computer1 = m.GetBlockId("ComputerON");
            Lamp1 = m.GetBlockId("LampON");
            Lamp0 = m.GetBlockId("LampOFF");
            LightBulb0 = m.GetBlockId("LightBulbOFF");
            LightBulb1 = m.GetBlockId("LightBulbON");
            FluoressentTube0 = m.GetBlockId("FluoressentTubeOFF");
            FluoressentTube1 = m.GetBlockId("FluoressentTubeON");
            Chandelier0 = m.GetBlockId("ChandelierOFF");
            Chandelier1 = m.GetBlockId("ChandelierON");
            WoodFenceGate0 = m.GetBlockId("WoodFenceGateClosed");
            WoodFenceGate1 = m.GetBlockId("WoodFenceGateOpen");
            WoodTrapdoor0 = m.GetBlockId("WoodenTrapdoorOpen");
            WoodTrapdoor1 = m.GetBlockId("WoodenTrapdoorClosed");
            IronTrapdoor0 = m.GetBlockId("IronTrapdoorOpen");
            IronTrapdoor1 = m.GetBlockId("IronTrapdoorClosed");
            Pizza = m.GetBlockId("Pizza");
            FarmDirt = m.GetBlockId("DirtForFarming");
            Dirt = m.GetBlockId("Dirt");
            Grass = m.GetBlockId("Grass");
            PumpkinSeed = m.GetBlockId("PumpkinSeed");
            Pumpkin = m.GetBlockId("Pumpkin");
            PumpkinPlant = m.GetBlockId("PumpkinPlant");
            m.RegisterOnBlockUse(onUse);
            m.RegisterOnBlockUpdate(onUpdate);
            m.RegisterOnBlockDelete(onDelete);
        }
        Random rnd = new Random();
        ModManager m;
        int TV0;
        int TV1;
        int Computer0;
        int Computer1;
        int Lamp1;
        int Lamp0;
        int LightBulb0;
        int LightBulb1;
        int FluoressentTube0;
        int FluoressentTube1;
        int Chandelier0;
        int Chandelier1;
        int WoodFenceGate0;
        int WoodFenceGate1;
        int WoodTrapdoor0;
        int WoodTrapdoor1;
        int IronTrapdoor0;
        int IronTrapdoor1;
        int Pizza;
        int Dirt;
        int Grass;
        int FarmDirt;
        int PumpkinSeed;
        int Pumpkin;
        int PumpkinPlant;
        int n;
        
    void onUse(int player, int x, int y, int z)
        {
             if (m.GetBlock(x, y, z) == TV0)
            {
             m.SetBlock(x, y, z, TV1);
             }
            else if (m.GetBlock(x, y, z) == TV1)
            {
             m.SetBlock(x, y, z, TV0);
             }
             if (m.GetBlock(x, y, z) == Computer0)
            {
             m.SetBlock(x, y, z, Computer1);
             }
            else if (m.GetBlock(x, y, z) == Computer1)
            {
             m.SetBlock(x, y, z, Computer0);
             }
             if (m.GetBlock(x, y, z) == Lamp0)
            {
             m.SetBlock(x, y, z, Lamp1);
             }
            else if (m.GetBlock(x, y, z) == Lamp1)
            {
             m.SetBlock(x, y, z, Lamp0);
             }
            if (m.GetBlock(x, y, z) == LightBulb0)
            {
             m.SetBlock(x, y, z, LightBulb1);
             }
            else if (m.GetBlock(x, y, z) == LightBulb1)
            {
             m.SetBlock(x, y, z, LightBulb0);
             }
            if (m.GetBlock(x, y, z) == FluoressentTube0)
            {
             m.SetBlock(x, y, z, FluoressentTube1);
             }
            else if (m.GetBlock(x, y, z) == FluoressentTube1)
            {
             m.SetBlock(x, y, z, FluoressentTube0);
             }
            if (m.GetBlock(x, y, z) == Chandelier0)
            {
             m.SetBlock(x, y, z, Chandelier1);
             }
            else if (m.GetBlock(x, y, z) == Chandelier1)
            {
             m.SetBlock(x, y, z, Chandelier0);
             }
            if (m.GetBlock(x, y, z) == WoodFenceGate0)
            {
             m.SetBlock(x, y, z, WoodFenceGate1);
             }
            else if (m.GetBlock(x, y, z) == WoodFenceGate1)
            {
             m.SetBlock(x, y, z, WoodFenceGate0);
             }
            if (m.GetBlock(x, y, z) == WoodTrapdoor0)
            {
             m.SetBlock(x, y, z, WoodTrapdoor1);
             }
            else if (m.GetBlock(x, y, z) == WoodTrapdoor1)
            {
             m.SetBlock(x, y, z, WoodTrapdoor0);
             }
            if (m.GetBlock(x, y, z) == IronTrapdoor0)
            {
             m.SetBlock(x, y, z, IronTrapdoor1);
             }
            else if (m.GetBlock(x, y, z) == IronTrapdoor1)
            {
             m.SetBlock(x, y, z, IronTrapdoor0);
             }
        
        //Bellow code was stolen from Food.cs
        
        if (m.GetBlock(x, y, z) == Pizza)
			{
				int health = m.GetPlayerHealth(player);
				int maxhealth = m.GetPlayerMaxHealth(player);

				health += 30;

				if (health > maxhealth)
				{
					health = maxhealth;
				}

				m.SetPlayerHealth(player, health, maxhealth);
				m.SetBlock(x, y, z, 0);
			}
         }
        void onUpdate(int x, int y, int z)
        {
             if(m.GetBlock(x,y,z) == FarmDirt && m.GetBlock(x,y,z+1) == PumpkinSeed)
             {
                  m.SetBlock(x,y,z+1,PumpkinPlant);
             }
             else if(m.GetBlock(x,y,z) == FarmDirt && m.GetBlock(x,y,z+1) == PumpkinPlant)
             {
                  m.SetBlock(x,y,z+1,Pumpkin);
             }
        }
        
        
    // Bellow code was stolen from CoreBlocks.cs
        
		int lastseason;
		void UpdateSeasons()
		{
			int currentSeason = (int)((m.GetYear() % 1) * 4);
			if (currentSeason != lastseason)
			{
				// spring
				if (currentSeason == 0)
				{
                 m.SetBlockType(n+8, "ClearGlass", new BlockType()
				  {
					TopBottomTextures = "ClearGlass",
					SideTextures = "ClearGlass",
					TextureIdForInventory = "ClearGlassInventory",
					DrawType = DrawType.Fence,
					WalkableType = WalkableType.Solid,
					Sounds = solidSounds,
				  });
				}
				// summer
				if (currentSeason == 1)
				{
				}
				// autumn
				if (currentSeason == 2)
				{
				}
				// winter
				if (currentSeason == 3)
				{
                    m.SetBlockType(n+8, "ClearGlass", new BlockType()
				        {
					        AllTextures = "WinterGlass",
				            DrawType = DrawType.Fence,
					        WalkableType = WalkableType.Solid,
				        	Sounds = snowSounds,
				       });
				}
                
				//Send updated BlockTypes to players
				m.UpdateBlockTypes();
				lastseason = currentSeason;
                
				//Readd "lost blocks" to inventory
                m.AddToCreativeInventory("ClearGlass");
			}
        }

         void onDelete(int player, int x, int y, int z, int block)
        {
            if(!m.IsCreative())
            {
                if(block == Dirt || block == Grass)
                {
                    if(rnd.NextDouble() < 0.1)
                    {
                      m.GrabBlock(player, PumpkinSeed);
                    }
                }
            }
        }
	}
}