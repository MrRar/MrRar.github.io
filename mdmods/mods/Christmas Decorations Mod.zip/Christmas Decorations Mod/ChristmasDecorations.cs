/******************************************
Christmas Decorations v2.0
Author:Mr. Rar
Block IDs used:431-439

Feel free to edit this mod to your liking.
*******************************************/
using System;

namespace ManicDigger.Mods
{

	public class ChristmasDecorations : IMod
	{
		ModManager m;
		SoundSet solidSounds;

		public void PreStart(ModManager m)
		{
			m.RequireMod("Core");
		}
		public void Start(ModManager manager)
		{
			m = manager;
			solidSounds = new SoundSet()
			{
				Walk = new string[] { "walk1", "walk2", "walk3", "walk4" },
				Break = new string[] { "destruct" },
				Build = new string[] { "build" },
				Clone = new string[] { "clone" },
			};
			
			 m.SetBlockType(432, "Wreath", new BlockType()
			               {
                            AllTextures = "Wreath",
			               	DrawType = DrawType.Ladder,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
			m.SetBlockType(433, "ChristmasTreeTop", new BlockType()
			               {
                            AllTextures = "ChristmasTreeTop",
			               	DrawType = DrawType.Plant,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(434, "ChristmasTreeMiddle", new BlockType()
			               {
                            AllTextures = "ChristmasTreeMiddle",
			               	DrawType = DrawType.Plant,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
            m.SetBlockType(435, "ChristmasTreeBottom", new BlockType()
			               {
                            AllTextures = "ChristmasTreeBottom",
			               	DrawType = DrawType.Plant,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
             m.SetBlockType(436, "SnowmanBody", new BlockType()
			               {
                            AllTextures = "SnowmanBody",
			               	DrawType = DrawType.Solid,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
             m.SetBlockType(437, "SnowmanHead", new BlockType()
			               {
                            TopBottomTextures = "SnowmanHeadTop",
                            SideTextures = "SnowmanHead",
                            TextureIdForInventory = "SnowmanHead",
			               	DrawType = DrawType.Cactus,
			               	WalkableType = WalkableType.Solid,
			               	Sounds = solidSounds,
			               });
             m.SetBlockType(438, "SnowmanHand", new BlockType()
			               {
                            AllTextures = "SnowmanHand",
			               	DrawType = DrawType.Fence,
			               	WalkableType = WalkableType.Empty,
			               	Sounds = solidSounds,
			               });
             m.SetBlockType(439, "CandyCane", new BlockType()
			               {
                            AllTextures = "CandyCane",
			               	DrawType = DrawType.Fence,
			               	WalkableType = WalkableType.Empty,
			               	Sounds = solidSounds,
			               });
            m.AddToCreativeInventory("Wreath");
			m.AddToCreativeInventory("ChristmasTreeTop");
            m.AddToCreativeInventory("ChristmasTreeMiddle");
            m.AddToCreativeInventory("ChristmasTreeBottom");
            m.AddToCreativeInventory("SnowmanBody");
            m.AddToCreativeInventory("SnowmanHead");
            m.AddToCreativeInventory("SnowmanHand");
            m.AddToCreativeInventory("CandyCane");
            m.AddCraftingRecipe("CandyCane", 1, "OakWood", 1);
            m.AddCraftingRecipe("CandyCane", 1, "BirchWood", 1);
            m.AddCraftingRecipe("CandyCane", 1, "SpruceWood", 1);
            m.AddCraftingRecipe("SnowmanHand", 2, "OakWood", 1);
            m.AddCraftingRecipe("SnowmanHand", 2, "BirchWood", 1);
            m.AddCraftingRecipe("SnowmanHand", 2, "SpruceWood", 1);
            m.AddCraftingRecipe("ChristmasTreeTop", 1, "SpruceLeaves", 1);
            m.AddCraftingRecipe("ChristmasTreeMiddle", 1, "SpruceLeaves", 1);
            m.AddCraftingRecipe("ChristmasTreeBottom", 1, "SpruceLeaves", 1);
            m.AddCraftingRecipe("Wreath", 1, "SpruceLeaves", 1);
            m.AddCraftingRecipe("SnowmanBody", 1, "Dirt", 2);
            m.AddCraftingRecipe("SnowmanHead", 1, "Dirt", 2);
        }
	}
}
